package mobile.paluno.de.palaver.gcm;


public interface NotificationListener {

    void onNotificationReceived();
    String getChatName();
}
